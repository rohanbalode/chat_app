import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import UserList from './UserList';
import ChatWindow from './ChatWindow';
import './ChatDashboard.css';

const API_URL = 'http://localhost:8000';
const WS_URL = 'ws://localhost:8000';

function ChatDashboard() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [ws, setWs] = useState(null);
  const navigate = useNavigate();
  const wsRef = useRef(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      setCurrentUser(user);
    }

    fetchUsers();
    connectWebSocket();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const connectWebSocket = () => {
    const token = localStorage.getItem('token');
    if (!token) return;

    const websocket = new WebSocket(`${WS_URL}/ws/${token}`);

    websocket.onopen = () => {
      console.log('WebSocket Connected');
      setWs(websocket);
      wsRef.current = websocket;
    };

    websocket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'user_status') {
        setOnlineUsers(data.online_users);
      }
    };

    websocket.onclose = () => {
      console.log('WebSocket Disconnected');
      // Attempt to reconnect after 3 seconds
      setTimeout(() => {
        connectWebSocket();
      }, 3000);
    };

    websocket.onerror = (error) => {
      console.error('WebSocket Error:', error);
    };
  };

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/users`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
      if (error.response?.status === 401) {
        handleLogout();
      }
    }
  };

  const handleSearch = async (query) => {
    setSearchQuery(query);
    
    if (query.trim() === '') {
      fetchUsers();
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/users/search?q=${query}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(response.data);
    } catch (error) {
      console.error('Error searching users:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    if (wsRef.current) {
      wsRef.current.close();
    }
    navigate('/login');
  };

  return (
    <div className="chat-dashboard">
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="user-profile">
            <div className="user-avatar">{currentUser?.name?.charAt(0).toUpperCase()}</div>
            <div className="user-info">
              <h3>{currentUser?.name}</h3>
              <span className="status-online">Online</span>
            </div>
          </div>
          <button className="logout-btn" onClick={handleLogout}>Logout</button>
        </div>
        
        <div className="search-container">
          <input
            type="text"
            placeholder="🔍 Search users..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="search-input"
          />
        </div>
        
        <UserList
          users={users}
          selectedUser={selectedUser}
          onSelectUser={setSelectedUser}
          onlineUsers={onlineUsers}
        />
      </div>
      
      <div className="main-content">
        {selectedUser ? (
          <ChatWindow
            selectedUser={selectedUser}
            currentUser={currentUser}
            ws={ws}
          />
        ) : (
          <div className="no-chat-selected">
            <div className="empty-state">
              <h2>💬</h2>
              <h3>Select a user to start chatting</h3>
              <p>Choose a contact from the left panel to begin a conversation</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default ChatDashboard;
