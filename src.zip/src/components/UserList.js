import React from 'react';
import './UserList.css';

function UserList({ users, selectedUser, onSelectUser, onlineUsers }) {
  const isOnline = (userId) => {
    return onlineUsers.includes(userId);
  };

  return (
    <div className="user-list">
      <h4 className="user-list-title">Contacts ({users.length})</h4>
      {users.length === 0 ? (
        <div className="no-users">
          <p>No users found</p>
        </div>
      ) : (
        <div className="user-list-items">
          {users.map((user) => (
            <div
              key={user.id}
              className={`user-item ${selectedUser?.id === user.id ? 'active' : ''}`}
              onClick={() => onSelectUser(user)}
            >
              <div className="user-avatar-container">
                <div className="user-avatar">{user.name.charAt(0).toUpperCase()}</div>
                {isOnline(user.id) && <span className="online-indicator"></span>}
              </div>
              <div className="user-details">
                <div className="user-name">{user.name}</div>
                <div className="user-status">
                  {isOnline(user.id) ? (
                    <span className="status-text online">Online</span>
                  ) : (
                    <span className="status-text offline">Offline</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default UserList;
